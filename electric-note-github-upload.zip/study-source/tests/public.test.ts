import {it,expect} from 'vitest';
import data from '../public/content/starter.json';
import {parsePack} from '../src/content';
it('공개 기본 팩은 실제 기출 원문을 포함하지 않는다',()=>{const p=parsePack(data);expect(p.days).toHaveLength(3);expect(p.days.flatMap(d=>d.questions)).toHaveLength(10);expect(p.days.flatMap(d=>d.questions).every(q=>q.type==='generated')).toBe(true);});
