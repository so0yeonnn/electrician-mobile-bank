import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import {VitePWA} from 'vite-plugin-pwa';
const base=process.env.CBT_BASE||'/';
export default defineConfig({base,publicDir:process.env.CBT_PUBLIC_MODE==='1'?'.deployment/public':'public',plugins:[react(),VitePWA({registerType:'prompt',includeAssets:['icon.svg','icon-192.png','icon-512.png','content/question-classification.csv'],manifest:{id:base,name:'전기노트 — 전기직 개인 학습 CBT',short_name:'전기노트',lang:'ko',description:'개념에서 백지 복습까지, 나의 전기직 학습 루틴',theme_color:'#164f46',background_color:'#f5f6f3',display:'standalone',start_url:base,scope:base,icons:[{src:base+'icon-192.png',sizes:'192x192',type:'image/png',purpose:'any'},{src:base+'icon-512.png',sizes:'512x512',type:'image/png',purpose:'any'},{src:base+'icon.svg',sizes:'any',type:'image/svg+xml',purpose:'any'}]},workbox:{globPatterns:['**/*.{js,css,html,svg,json,woff,woff2}'],maximumFileSizeToCacheInBytes:4000000}})]});
