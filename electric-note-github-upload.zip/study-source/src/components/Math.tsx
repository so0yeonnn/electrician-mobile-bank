import katex from 'katex';
import {useMemo} from 'react';
export function MathBlock({tex}:{tex:string}){const html=useMemo(()=>katex.renderToString(tex,{throwOnError:false,trust:false,strict:'warn',displayMode:true,output:'htmlAndMathml',maxExpand:200,maxSize:12}),[tex]);return <div className="math" dangerouslySetInnerHTML={{__html:html}}/>;}
