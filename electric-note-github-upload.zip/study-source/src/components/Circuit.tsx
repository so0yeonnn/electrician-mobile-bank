import {useRef} from 'react';
import {ZoomIn,X} from 'lucide-react';
export function Circuit({kind}:{kind:'ohm'|'parallel'|'power'}){
 const modal=useRef<HTMLDialogElement>(null);
 const drawing=<svg viewBox="0 0 480 210" role="img" aria-label={kind==='parallel'?'같은 두 노드에 연결된 R1과 R2 병렬 회로':'직류 전원 V에 저항 R을 연결한 회로'}>
 <g fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinejoin="round"><path d="M70 80V40H350V75M350 135V175H70V130"/><circle cx="70" cy="105" r="25"/>
 {kind==='parallel'?<><path d="M220 40V75M220 135V175"/><rect x="207" y="75" width="26" height="60"/><rect x="337" y="75" width="26" height="60"/><circle cx="220" cy="40" r="4" fill="currentColor"/><circle cx="220" cy="175" r="4" fill="currentColor"/></>:<rect x="337" y="75" width="26" height="60"/>}<path d="M160 40h35l-8-6m8 6-8 6"/></g><g fill="currentColor" fontFamily="sans-serif" fontSize="17"><text x="42" y="65">V</text><text x="63" y="102">+</text><text x="64" y="120">−</text><text x="165" y="27">I →</text><text x="375" y="110">{kind==='parallel'?'R₂':'R'}</text>{kind==='parallel'&&<text x="244" y="110">R₁</text>}{kind==='power'&&<text x="150" y="145">P = VI</text>}</g></svg>;
 return <><figure className="circuit"><div>{drawing}</div><figcaption>이상 전원 · 직류 정상상태 <button className="text-button" onClick={()=>modal.current?.showModal()}><ZoomIn size={16}/> 회로도 확대</button></figcaption></figure><dialog ref={modal} className="zoom-dialog"><button className="icon-button" aria-label="확대 닫기" onClick={()=>modal.current?.close()}><X/></button><p>회로도 · 가로로 밀어 자세히 보기</p><div className="zoom-scroll">{drawing}</div></dialog></>;
}
