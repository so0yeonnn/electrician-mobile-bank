import {eligible,type Day,type Question} from './content';
export const difficultyLabels=['','기초','쉬움','응용','도전'];
export const priorityLabels={core:'핵심 학습',additional:'추가 연습',mock:'실전 CBT용'};
export function selectDailyQuestions(day:Day,kind:Question['type'],short=false){
 return day.questions.filter(q=>q.type===kind&&eligible(q)&&(!q.classification||q.classification.priority==='core'))
 .sort((a,b)=>{
  const stage=(q:Question)=>q.classification?.stage==='applied-past'?1:0;
  return stage(a)-stage(b)||(a.classification?.difficulty??2)-(b.classification?.difficulty??2);
 }).slice(0,kind==='past'?6:short?2:4);
}
export function classificationCSV(pack:{days:Day[]}){
 const rows:(string|number)[][]=[['ID','유형','과목','세부개념','난이도','우선순위','학습단계'],...pack.days.flatMap(d=>d.questions.map(q=>[q.id,q.type,q.classification?.subject||'',q.classification?.concepts.join(' / ')||'',q.classification?.difficulty||'',q.classification?.priority||'',q.classification?.stage||'']))];
 return '\uFEFF'+rows.map(row=>row.map(value=>{let s=String(value);if(/^[=+@-]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"';}).join(',')).join('\r\n')+'\r\n';
}
