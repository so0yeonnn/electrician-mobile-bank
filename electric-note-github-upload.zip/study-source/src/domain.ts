import {parse} from 'mathjs';
import type {Progress,Session} from './storage';
import type {Formula} from './content';
export type Confidence = 'sure'|'unsure'|'guess';
export function localDate(date=new Date()){return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;}
export function reviewDates(today:string){return [1,3,7,14].map(n=>{const d=new Date(today+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10);});}
function safeExpression(expression:string,scope:Record<string,number>){
 if(expression.length>240)throw Error('식이 너무 깁니다.');
 const node=parse(expression); let count=0;
 node.traverse(n=>{if(++count>80)throw Error('식이 너무 복잡합니다.');const a=n as unknown as {type:string,name:string,op:string,value:number};if(a.type==='SymbolNode'){if(!Object.hasOwn(scope,a.name))throw Error('허용되지 않은 기호');}else if(a.type==='OperatorNode'){if(!['+','-','*','/','^'].includes(a.op))throw Error('허용되지 않은 연산');}else if(!['ConstantNode','ParenthesisNode'].includes(a.type))throw Error('함수나 코드는 허용하지 않음');});
 const result=node.evaluate(scope);if(typeof result!=='number'||!Number.isFinite(result))throw Error('유한 실수가 아님');return result;
}
export function gradeFormula(input:string,lhs:string,expression:string,samples:Record<string,number>[]){
 try{let value=input.trim().replaceAll('×','*').replaceAll('÷','/').replaceAll('ρ','rho').replaceAll('²','^2').replaceAll('³','^3');if(value.includes('=')){const parts=value.split('=');if(parts.length!==2||parts[0].trim()!==lhs)return false;value=parts[1];}return samples.length>=3 && samples.every(s=>Math.abs(safeExpression(value,s)-safeExpression(expression,s))<=1e-8*Math.max(1,Math.abs(safeExpression(expression,s))));}catch{return false;}
}
export function gradeRecallFormula(input:string,f:Formula){return gradeFormula(input,f.lhs,f.expression,f.samples);}
export function freshSession(mode:Session['mode']):Session{return {step:0,mode,drafts:{},answers:{},examDeferred:false,startedAt:new Date().toISOString()};}
export function recordAttempt(p:Progress,a:Omit<Progress['attempts'][number],'id'|'at'>,today=localDate()):Progress{
 const next=structuredClone(p);next.attempts.push({...a,id:crypto.randomUUID(),at:new Date().toISOString()});
 if(!a.correct||a.confidence!=='sure')next.reviews[a.itemId]={itemId:a.itemId,conceptId:a.conceptId,kind:a.kind,dates:reviewDates(today)};
 else if(next.reviews[a.itemId]){next.reviews[a.itemId].dates=next.reviews[a.itemId].dates.filter(d=>d>today);if(!next.reviews[a.itemId].dates.length)delete next.reviews[a.itemId];}
 return next;
}
export function dueReviews(p:Progress,today=localDate()){return Object.values(p.reviews).filter(r=>r.dates.some(d=>d<=today)).sort((a,b)=>a.dates[0].localeCompare(b.dates[0])).slice(0,5);}
export function latestAttempts(p:Progress){return Object.values(Object.fromEntries(p.attempts.map(a=>[a.itemId,a])));}
