import {z} from 'zod';
const text = z.string().trim().min(1).max(12000);
const id=z.string().regex(/^[a-z0-9-]+$/).max(80);
export const verificationSchema=z.object({status:z.enum(['verified','errata','suspected','unreadable','unreviewed']),imageCompared:z.boolean(),ocrCompared:z.boolean(),choicesCompared:z.boolean(),diagramCompared:z.boolean(),independentSolution:text,numericCheck:text,ambiguityCheck:text,errataNote:text}).strict();
const source=z.object({book:text,year:z.number().int().min(1980).max(2100),round:text,number:z.number().int().positive(),page:z.number().int().positive(),pdfPage:z.number().int().positive().optional(),paperType:z.enum(['cbt-reconstruction','written-paper']).optional(),reference:text}).strict();
const concept=z.object({id,title:text,source:z.object({book:text,pdfPage:z.number().int().positive(),printedPage:text,section:text,note:text}).strict().optional(),body:z.array(text).min(2).max(10),latex:text,symbols:text,condition:text,example:text,pitfall:text}).strict();
const formula=z.object({id,conceptId:id,prompt:text,lhs:z.string().regex(/^[A-Za-z][A-Za-z0-9_]*$/),expression:text,latex:text,symbol:text,meaning:text,meaningChoices:z.array(text).length(3),unit:text,unitChoices:z.array(text).length(3),condition:text,conditionChoices:z.array(text).length(3),samples:z.array(z.record(z.string(),z.number().finite())).min(3).max(10)}).strict();
const check=z.object({model:z.enum(['ohm','charge','resistance','series','parallel','kcl','divider','power','energy','heat','temperature','power-ratio','parallel-n','batteries','efficiency','wave-rms','crest-duty','complex-magnitude']),inputs:z.array(z.number().finite()).min(2).max(5),expected:z.number().finite(),decimals:z.number().int().min(0).max(8).optional()}).strict();
const classification=z.object({subject:z.enum(['전기자기학','전력공학','전기기기','회로이론 및 제어공학','전기설비기술기준']),concepts:z.array(text).min(1).max(8),prerequisiteConceptIds:z.array(id).max(12),difficulty:z.number().int().min(1).max(4),priority:z.enum(['core','additional','mock']),stage:z.enum(['easy-past','applied-past','variant']),rationale:text}).strict();
const learningPolicy=z.object({requiredSources:z.tuple([z.literal('summary'),z.literal('exams')]),analysisYears:z.object({from:z.number().int(),to:z.number().int()}).strict().refine(y=>y.to-y.from===6,'분석 범위는 연속7개년이어야 합니다.'),classificationScope:z.literal('all-supplied-exams'),strategy:z.literal('common-electrical-core'),ordering:z.tuple([z.literal('concept'),z.literal('formula'),z.literal('easy-past'),z.literal('applied-past'),z.literal('variant')]),remainingUse:z.tuple([z.literal('additional'),z.literal('mock')]),unverified:z.literal('exclude')}).strict();
const question=z.object({id,conceptId:id,type:z.enum(['generated','past']),prompt:text,classification:classification.optional(),context:text.optional(),image:z.object({dataUrl:z.string().max(3000000).regex(/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/),alt:text,caption:text}).strict().optional(),choices:z.array(z.object({text,value:z.number().finite().optional()}).strict()).length(4),answer:z.number().int().min(0).max(3),latex:text,explanation:z.object({principle:text,steps:z.array(text).min(1),shortcut:text,pitfall:text}).strict(),check:check.nullable(),verification:verificationSchema,source:source.nullable()}).strict();
const day=z.object({id,order:z.number().int().positive(),title:text,subtitle:text,prerequisites:z.array(id),concepts:z.array(concept).min(2).max(10),formulas:z.array(formula).min(1).max(8),questions:z.array(question).max(30),recall:z.array(z.object({conceptId:id,prompt:text,keyPoints:text}).strict()).min(1),interview:z.array(z.object({question:text,answer:text}).strict()).max(6),diagram:z.enum(['ohm','parallel','power','waveforms'])}).strict();
export const packSchema=z.object({schemaVersion:z.literal(1),id,title:text,revision:text,notice:text,learningPolicy:learningPolicy.optional(),sources:z.array(z.object({id,title:text,type:z.enum(['summary','exams','selection']),status:z.enum(['available','missing']),reference:text,pages:z.number().int().positive().optional(),sha256:text.optional()}).strict()).optional(),audit:z.object({scope:text,limitations:text,errataStatus:text,findings:z.array(text)}).strict().optional(),days:z.array(day).min(1).max(90)}).strict();
export type Pack=z.infer<typeof packSchema>;
export type Day=Pack['days'][number];
export type Formula=Day['formulas'][number];
export type Question=Day['questions'][number];
export function computeCheck(c:NonNullable<Question['check']>):number{
 const [a,b,d,e,f]=c.inputs;let value:number;
 switch(c.model){case 'wave-rms':value=Math.abs(a)*Math.sqrt(b);break;case 'crest-duty':value=Math.abs(a)/Math.sqrt(a*a*b);break;case 'complex-magnitude':value=Math.hypot(a,b);break;case 'ohm':case 'charge':value=a/b;break;case 'resistance':value=a*b/d;break;case 'series':value=a+b;break;case 'parallel':value=a*b/(a+b);break;case 'kcl':value=a+b-d;break;case 'divider':value=a*b/(b+d);break;case 'power':case 'energy':value=a*b;break;case 'heat':value=a*a*b*d;break;case 'temperature':value=a*b/d*(1+e*f);break;case 'power-ratio':value=a*b*b;break;case 'parallel-n':value=a/b;break;case 'batteries':value=a*b/d;break;case 'efficiency':value=a*860/(b*d)*100;break;}
 return c.decimals===undefined?value:Number(value.toFixed(c.decimals));
}
export function eligible(q:Question):boolean{
 const v=q.verification;
 if(!['verified','errata'].includes(v.status))return false;
 if(q.type==='past') return !!q.source && v.imageCompared && v.ocrCompared && v.choicesCompared && v.diagramCompared;
 return !!q.check && Math.abs(computeCheck(q.check)-q.check.expected)<1e-8 && q.choices[q.answer].value===q.check.expected;
}
export function parsePack(raw:unknown):Pack{
 const p=packSchema.parse(raw); const allConcepts=new Set(p.days.flatMap(d=>d.concepts.map(c=>c.id)));if(p.learningPolicy&&(!p.sources||p.sources.length!==2||!p.sources.some(s=>s.type==='summary')||!p.sources.some(s=>s.type==='exams')))throw Error('학습 자료는 핵심요약본과7개년기출PDF두가지입니다.'); const ids=new Set<string>(); const prior=new Set<string>();
 for(const d of p.days){
  for(const value of [d.id,...d.concepts.map(x=>x.id),...d.formulas.map(x=>x.id),...d.questions.map(x=>x.id)]){if(ids.has(value))throw Error('중복 ID: '+value);ids.add(value);}
  if(d.prerequisites.some(x=>!prior.has(x)))throw Error('선수 단원은 현재 단원 앞에 있어야 합니다.');prior.add(d.id);
  const concepts=new Set(d.concepts.map(c=>c.id));
  if([...d.formulas,...d.questions,...d.recall].some(q=>!concepts.has(q.conceptId)))throw Error('없는 개념을 참조합니다.');
  for(const f of d.formulas){if(!f.meaningChoices.includes(f.meaning)||!f.unitChoices.includes(f.unit)||!f.conditionChoices.includes(f.condition))throw Error('공식 퀴즈 정답이 선택지에 없습니다.');}
  for(const q of d.questions){if(p.learningPolicy&&!q.classification)throw Error('문항 분류가 필요합니다: '+q.id);if(q.classification){if(q.classification.prerequisiteConceptIds.some(ref=>!allConcepts.has(ref)))throw Error('없는 선수 개념: '+q.id);if((q.type==='generated')!==(q.classification.stage==='variant'))throw Error('문항 유형과 학습 단계가 다릅니다: '+q.id);}if(new Set(q.choices.map(c=>c.text.replace(/\s+/g,' ').trim())).size!==4)throw Error('중복 선택지: '+q.id);if(q.check){const count=q.check.model==='temperature'?5:['resistance','kcl','divider','heat','batteries','efficiency'].includes(q.check.model)?3:2;if(q.check.inputs.length!==count)throw Error('검산 입력 개수 불일치: '+q.id);if(q.choices.filter(c=>c.value===q.check!.expected).length!==1)throw Error('수치 검산 불일치: 정답 수치와 같은 선택지가 복수이거나 없습니다: '+q.id);}if(q.type==='past' && !q.source)throw Error('기출에는 원문 출처가 필요합니다.');if(q.type==='generated' && q.source)throw Error('자체 제작 문제에 기출 출처를 지정할 수 없습니다.');if(q.check && (!Number.isFinite(computeCheck(q.check)) || Math.abs(computeCheck(q.check)-q.check.expected)>1e-8 || q.choices[q.answer].value!==q.check.expected))throw Error('수치 검산 불일치: '+q.id);}
 }
 return p;
}
