import {parsePack,type Pack} from './content';
import {emptyProgress,parseBackup,type Progress} from './storage';
export async function decryptPersonalPack(encodedKey:string,payload:ArrayBuffer):Promise<Pack>{
 if(!/^[A-Za-z0-9_-]{43}$/.test(encodedKey))throw Error('개인 학습 링크가 올바르지 않습니다.');
 const keyBytes=Uint8Array.from(atob(encodedKey.replaceAll('-','+').replaceAll('_','/')+'='),c=>c.charCodeAt(0));
 const bytes=new Uint8Array(payload);
 if(bytes.length<30||bytes.length>8*1024*1024||bytes[0]!==1)throw Error('개인 학습팩 형식을 확인할 수 없습니다.');
 const key=await crypto.subtle.importKey('raw',keyBytes,{name:'AES-GCM'},false,['decrypt']);
 let plain:ArrayBuffer;
 try{plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:bytes.slice(1,13),additionalData:new TextEncoder().encode('electric-note-personal-pack-v1')},key,bytes.slice(13));}
 catch{throw Error('개인 학습팩을 열지 못했습니다. 이 대화의 개인 링크로 다시 열어 주세요.');}
 return parsePack(JSON.parse(new TextDecoder().decode(plain)));
}
type Snapshot={pack:Pack,progress:Progress};
export function activatePersonalPack(current:Snapshot|undefined,pack:Pack):Snapshot{
 if(!current)return {pack,progress:emptyProgress()};
 if(current.pack.id===pack.id&&current.pack.revision===pack.revision)return current;
 if(current.pack.id===pack.id){parseBackup({format:'electric-cbt-backup',version:1,exportedAt:new Date().toISOString(),pack,progress:current.progress});return {pack,progress:current.progress};}
 if(current.pack.id!=='electrical-foundations-public')throw Error('다른 학습팩을 사용 중입니다. 설정에서 기록을 백업한 뒤 개인 학습팩을 가져와 주세요.');
 const progress=structuredClone(current.progress);
 for(const session of Object.values(progress.sessions))if(session.examDeferred||session.finishedAt){session.step=Math.min(session.step,2);session.examDeferred=false;delete session.finishedAt;}
 // Validate every retained record against the new content before replacing anything.
 parseBackup({format:'electric-cbt-backup',version:1,exportedAt:new Date().toISOString(),pack,progress});
 return {pack,progress};
}
export async function personalPackFromLink(base:string):Promise<Pack|undefined>{
 if(!location.hash.startsWith('#activate='))return;
 const key=location.hash.slice('#activate='.length);
 const response=await fetch(base+'content/personal.pack');
 if(!response.ok)throw Error('개인 학습팩을 불러오지 못했습니다. 인터넷 연결 후 다시 열어 주세요.');
 return decryptPersonalPack(key,await response.arrayBuffer());
}
