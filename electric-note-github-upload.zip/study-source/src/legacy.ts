import type {Pack} from './content';
// Exact normalized fingerprint of the shipped0.1 pack. Edited/imported packs remain user-owned.
const legacyHash='a9ac7293822c36a943fdff8b5b573812595af9ff8ae226d5f99d2d980a41de56';
export async function isLegacyPack(pack:Pack){
 if(pack.id!=='electrical-foundations'||pack.revision!=='2026-10-29'||!globalThis.crypto?.subtle)return false;
 const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(pack)));
 return [...new Uint8Array(bytes)].map(b=>b.toString(16).padStart(2,'0')).join('')===legacyHash;
}

export async function isShippedV02Pack(pack:Pack){
 if(pack.id!=='electrical-foundations'||pack.revision!=='2026-10-29-sources-1'||!globalThis.crypto?.subtle)return false;
 const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(pack)));
 return [...new Uint8Array(bytes)].map(b=>b.toString(16).padStart(2,'0')).join('')==='3d4fa5bfbd009a78fa76d94ac2f7374358406ce7442d0d35c7a4ef9b6b798a9b';
}
