import type {Pack} from './content';
export function createPublicPack(pack:Pack):Pack{
 const safe=structuredClone(pack);
 safe.id='electrical-foundations-public';safe.title='전기노트 · 기초 체험 및 개인 학습팩';safe.revision='public-'+pack.revision;
 safe.notice=`공개 앱에는 기출 원문을 포함하지 않았습니다. 개인 학습 링크로 열면 검수한 기출${pack.days.flatMap(d=>d.questions).filter(q=>q.type==='past').length}문제와 ${pack.days.length}회 학습이 자동 연결됩니다. JSON 가져오기도 지원합니다. 기초 개념과 자체 제작 연습은 지금 바로 체험할 수 있습니다. 가져온 팩과 학습 기록은 이 기기에만 저장됩니다.`;
 safe.sources=safe.sources?.map(({sha256,...s})=>({...s,status:'missing',reference:'개인 학습팩으로 연결합니다. PDF 원본은 공개 앱에 포함하지 않습니다.'}));
 safe.audit={scope:'공개 기본 팩: 기초 개념·공식과 자체 제작'+pack.days.flatMap(d=>d.questions).filter(q=>q.type==='generated').length+'문제. 검수한 기출은 개인 링크로 연결한 뒤 이용합니다.',limitations:'개인 학습팩을 가져오기 전에는 실제 기출이 없습니다. 7개년 전체 문항의 분류·검수가 완료된 것은 아닙니다.',errataStatus:'공식 정오표 반영 상태는 가져온 개인 학습팩의 검수 기록에서 확인하세요.',findings:[]};
 for(const day of safe.days){day.questions=day.questions.filter(q=>q.type==='generated');}
 return safe;
}
