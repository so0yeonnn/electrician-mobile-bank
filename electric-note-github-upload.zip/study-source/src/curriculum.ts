import data from '../public/content/curriculum-60.json';
import {eligible,type Pack} from './content';
import type {Progress} from './storage';
export const curriculum=data;
export type PlannedDay=typeof curriculum.days[number];
export function linkedLesson(row:PlannedDay,pack:Pack){return row.lessonId?pack.days.find(d=>d.id===row.lessonId):undefined;}
export function lessonReady(row:PlannedDay,pack:Pack){const d=linkedLesson(row,pack);return !!d&&d.concepts.length>=2&&d.formulas.length>0&&d.recall.length>0&&d.questions.filter(q=>q.type==='past'&&eligible(q)).length>=3&&d.questions.filter(q=>q.type==='generated'&&eligible(q)).length>=2;}
export function courseProgress(pack:Pack,progress:Progress){return {ready:curriculum.days.filter(d=>lessonReady(d,pack)).length,completed:curriculum.days.filter(d=>lessonReady(d,pack)&&!!progress.sessions[d.lessonId!]?.finishedAt).length,total:curriculum.targetDays};}
export function canStartPlan(row:PlannedDay,pack:Pack,progress:Progress){return lessonReady(row,pack)&&(!!progress.sessions[row.lessonId!]||row.prerequisites.every(n=>{const prerequisite=curriculum.days.find(d=>d.day===n);return !!prerequisite?.lessonId&&!!progress.sessions[prerequisite.lessonId]?.finishedAt;}));}
