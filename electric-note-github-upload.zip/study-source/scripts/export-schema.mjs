import {writeFileSync} from 'node:fs';
import {z} from 'zod';
import {packSchema} from '../src/content.ts';
writeFileSync(new URL('../public/content/content.schema.json',import.meta.url),JSON.stringify(z.toJSONSchema(packSchema),null,2));
