import {cpSync,existsSync,mkdirSync,readFileSync,writeFileSync} from 'node:fs';
import {randomBytes,createCipheriv} from 'node:crypto';
import {rmSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {parsePack} from '../src/content.ts';
import {createPublicPack} from '../src/publicPack.ts';
const assets=new URL('../.deployment/public/',import.meta.url);mkdirSync(assets,{recursive:true});
cpSync(new URL('../public/',import.meta.url),assets,{recursive:true});
const pack=createPublicPack(parsePack(JSON.parse(readFileSync(new URL('../public/content/starter.json',import.meta.url),'utf8'))));
writeFileSync(new URL('content/starter.json',assets),JSON.stringify(pack,null,2));
const rows=[['ID','유형','과목','세부개념','난이도','우선순위','학습단계'],...pack.days.flatMap(d=>d.questions.map(q=>[q.id,q.type,q.classification.subject,q.classification.concepts.join(' / '),q.classification.difficulty,q.classification.priority,q.classification.stage]))];
writeFileSync(new URL('content/question-classification.csv',assets),'\uFEFF'+rows.map(r=>r.map(v=>'"'+String(v).replaceAll('"','""')+'"').join(',')).join('\r\n')+'\r\n');
rmSync(new URL('content/personal.pack',assets),{force:true});
if(process.env.CBT_PERSONAL_REUSE_PACK){
 if(process.env.CBT_PERSONAL_PACK)throw Error('개인 팩 새 암호화와 기존 암호문 재사용은 함께 지정할 수 없습니다.');
 const encrypted=readFileSync(process.env.CBT_PERSONAL_REUSE_PACK);
 if(encrypted.length<30||encrypted[0]!==1)throw Error('기존 개인 팩 형식 오류');
 writeFileSync(new URL('content/personal.pack',assets),encrypted);
}
if(process.env.CBT_PERSONAL_PACK){
 if(!process.env.CBT_PERSONAL_LINK_FILE)throw Error('개인 링크 저장 경로가 필요합니다.');
 const personal=parsePack(JSON.parse(readFileSync(process.env.CBT_PERSONAL_PACK,'utf8')));
 const key=randomBytes(32),iv=randomBytes(12),cipher=createCipheriv('aes-256-gcm',key,iv);
 cipher.setAAD(Buffer.from('electric-note-personal-pack-v1'));
 const encrypted=Buffer.concat([Buffer.from([1]),iv,cipher.update(JSON.stringify(personal)),cipher.final(),cipher.getAuthTag()]);
 writeFileSync(new URL('content/personal.pack',assets),encrypted);
 writeFileSync(process.env.CBT_PERSONAL_LINK_FILE,'https://so0yeonnn.github.io/electrician-mobile-bank/study/#activate='+key.toString('base64url')+'\n',{mode:0o600});
}
const result=spawnSync('npm',['run','build'],{stdio:'inherit',cwd:new URL('../',import.meta.url),env:{...process.env,CBT_PUBLIC_MODE:'1',CBT_BASE:'/electrician-mobile-bank/study/'}});
if(result.status!==0)process.exit(result.status??1);
const built=JSON.parse(readFileSync(new URL('../dist/content/starter.json',import.meta.url),'utf8'));
if(built.days.some(d=>d.questions.some(q=>q.type==='past')))throw Error('공개 산출물에 기출 원문이 포함됨');
console.log('PUBLIC_BUILD_READY: generated'+built.days.flatMap(d=>d.questions).length+'; private past0; scope /electrician-mobile-bank/study/');
