# 콘텐츠 작성 계약

단일 JSON 객체의 `schemaVersion`은 1입니다. 예제 `public/content/starter.json`과 JSON Schema를 함께 사용하세요. 추가 필드는 거절합니다. 렌더링 문자열은 일반 텍스트이며 `latex`만 KaTeX로 처리합니다. HTML과 임의 코드는 입력하지 않습니다.

- 팩: `id`, `title`, `revision`, `notice`, `days`.
- DAY: `id`, `order`, `title`, `subtitle`, `prerequisites`(앞에 등장한 DAY ID), `diagram`, `concepts`, `formulas`, `questions`, `recall`, `interview`.
- 개념: `id`, `title`, `body`(원리·초보 설명 문단), `latex`, `symbols`, `condition`, `example`, `pitfall`.
- 공식 퀴즈: `id`, `conceptId`, `prompt`, `lhs`, `expression`(계산용), `latex`(표시용), `symbol`, `meaning`, `meaningChoices`, `unit`, `unitChoices`, `condition`, `conditionChoices`, `samples`(3개 이상의 서로 다른 변수 대입).
- 문항: `id`, `conceptId`, `type`, `prompt`, `choices`(4개), `answer`(0부터 시작), `latex`, `explanation`, `check`, `verification`, `source`.
- 해설: `principle`, `steps`, `shortcut`, `pitfall`. 조건을 바꾼 문제의 원리와 계산을 독립적으로 검토합니다.
- 백지 복습: `conceptId`, `prompt`, `keyPoints`. 자기 평가용이며 정답 문자열 일치로 채점하지 않습니다.

ID는 영문 소문자·숫자·하이픈으로 만들고 팩 내에서 중복하지 않습니다. 공식·문제·복습은 같은 DAY의 개념 ID를 참조합니다. ID를 바꾸면 기존 기록과 연결되지 않으므로 백업을 보관하세요.

## 문항 검수

`type: "generated"`는 AI 자체 제작입니다. 원문과 대조 전에는 실제 기출을 변형한 것이라고 주장하지 마세요. `source`는 null, `check`는 필수로 작성합니다. 정답 선택지에는 숫자 `value`를 넣고 `check.expected`와 일치시킵니다. 단위는 `text`에 명시합니다.

지원 `check.model`과 `inputs`의 의미:

| 모델 | 입력 | 계산 |
|---|---|---|
| ohm, charge | a,b | a/b |
| resistance | ρ,l,A(SI) | ρl/A |
| series | R1,R2 | R1+R2 |
| parallel | R1,R2 | R1R2/(R1+R2) |
| kcl | 유입1,유입2,알려진 유출 | a+b−c |
| divider | V,R대상,R나머지 | V×R대상/(R대상+R나머지) |
| power | V,I | VI |
| energy | P,t(출력에 맞는 단위) | Pt |
| heat | I,R,t(s) | I²Rt |

수치 모델은 본문의 값을 자동 추출하지 않습니다. 본문·입력값·단위가 일치하는지는 작성자가 확인해야 합니다. 단순 계산 통과는 회로·공식·문장 조건 전체의 정확성을 증명하지 않습니다.

`type: "past"`는 출처의 `book`, `year`, `round`, `number`, `page`, `reference`를 모두 기록합니다. 문항이 없는 책·회차·페이지를 지어내면 안 됩니다. `reference`에 원본 파일명/페이지 식별 근거를 남깁니다. 출제 가능하려면:

1. 검수 상태 `verified`(검수 완료) 또는 `errata`(정오표 반영).
2. `imageCompared`, `ocrCompared`, `choicesCompared`, `diagramCompared`가 모두 true. 회로도가 없다면 검수 메모에 해당 없음 근거를 기록한 뒤 true로 둡니다.
3. `independentSolution`, `numericCheck`, `ambiguityCheck`, `errataNote`에 실질적인 검수 결과를 기록.
4. 원문 선택지와 정답을 독립 풀이와 대조. 부호·지수·단위·적용 조건을 원본 이미지와 확인.
5. 정오표가 확인되면 출판사 공식 링크, 조회일, 대상 판본, 변경 전후를 `errataNote`에 기록. 없거나 조회 불가하면 그 상태를 명시.

`check`가 있는 기출은 지원 모델로 수치 검산도 수행합니다. 비계산형은 null을 허용하되 `numericCheck`에 비계산형이라는 사유를 씁니다. `suspected`, `unreadable`, `unreviewed`는 화면에 상태를 남기지만 학습에서 제외합니다. 단원별 출제 가능한 기출이 3개 미만이면 기출 단계는 자료 대기입니다.

가져온 true 값과 검수 메모는 콘텐츠 작성자의 선언입니다. 앱은 실제 PDF·정오표에 접근해 그 선언을 입증하지 않습니다. PDF OCR 도구나 검수 시스템이 구현되었다고 주장하지 마세요.

문항의 선택적 `image`는 `{ "dataUrl": "data:image/png;base64,...", "alt": "회로 연결과 기호를 설명하는 대체 텍스트", "caption": "원문 교재 p.페이지의 회로도" }` 형식입니다. PNG/JPEG/WebP data URL만 허용하며 문자열 최대 3,000,000자, 전체 가져오기 파일 최대 8 MB입니다. 내장 회로도를 원문 회로도 대신 쓰지 마세요. 이미지를 원본과 대조하고 단자·부호·지수·해상도·저작물 사용 범위를 확인하세요. 복수 정답/조건 부족 문항도 검수 완료로 승격하지 않습니다.

## 제공 자료 연결판의 확장 필드

팩의 선택적 `sources`는 자료별 id/title/type/status/reference/pages/sha256를 기록합니다. `audit`는 scope/limitations/errataStatus/findings로 실제 검수 범위를 보고합니다. 개념의 `source`는 book/pdfPage/printedPage/section/note로 교재 근거와 새로 보충한 설명을 구별합니다. 문항 출처에는 `pdfPage`, `paperType`(cbt-reconstruction 또는 written-paper)를 추가할 수 있습니다. 인쇄 페이지와 PDF 페이지를 섞지 마세요.

추가 수치 모델:

| 모델 | inputs | 계산 |
|---|---|---|
| temperature | ρ,l,A,α,ΔT | ρl/A×(1+αΔT) |
| power-ratio | 기준P,전압비 | P×전압비² |
| parallel-n | 같은R,개수n | R/n |
| batteries | r,직렬개수n,병렬조수m | rn/m |
| efficiency | 출력kWh,발열량kcal/kg,질량kg | 출력×860/(발열량×질량)×100[%] |

`check.decimals`는 선택지에 맞춘 마지막 반올림 자릿수(0~8)입니다. 반올림 전 계산도 검수 메모와 별도 검산 코드에 남깁니다. 복합 답/노드해석처럼 내장 모델 한 개로 모두 확인할 수 없는 기출의 `check`는 null이고 `numericCheck`에 별도 코드·유도·결과를 명시합니다. null이 수치 검산 면제를 뜻하지는 않습니다. 제공 자료 연결판의 별도 검산 코드는 `scripts/verify-source-calculations.py`입니다.

문항의 선택적 `context`는 원문과 구별해야 하는 보충 조건을 답 제출 전에 표시합니다. 예를 들어 원문 그림에 생략된 전압 극성을 같은 교재 해설의 재도식에서 확인했을 때 그 근거를 공개합니다. 확인되지 않은 조건을 임의로 추가해 원문 기출이 완전하다고 표시하는 용도로 쓰지 마세요.

## 0.3 분류와 전체7개년 정책

`learningPolicy`가 있는 새 팩은 두PDF 출처만 등록하고 모든 문항의 `classification`을 채워야 합니다. `learningPolicy.requiredSources`는 `["summary","exams"]`, 분석 연도는 연속7개년, 범위는 `all-supplied-exams`입니다. 기존팩을 읽기 위해 `selection` 출처 값은 구버전 호환으로만 허용하고 앱의 필수자료 목록이나 새 기본팩에서 사용하지 않습니다.

`classification`: subject(원문 과목), concepts(세부 개념 목록), prerequisiteConceptIds(팩 내 실제 개념ID), difficulty(1~4), priority(core/additional/mock), stage(easy-past/applied-past/variant), rationale(공통 역량과의 연결 근거). 생성문제의 단계는variant이며 기출에variant를 붙이지 않습니다. 분류는 검수 상태와 별개입니다.

일일 선택기는 검수 필터를 통과한core만 사용하고, 기초 기출→응용 기출 안에서 난이도 오름차순으로 정렬합니다. 동률은 작성자가 정한 원리/선수 개념 순서를 유지합니다. 연도에 따른 필터나 정렬은 없습니다. 추가 연습/실전 CBT용을 일일 루틴의 빈자리에 자동 투입하지 않습니다. 해당 실행화면은 개발 예정입니다.
