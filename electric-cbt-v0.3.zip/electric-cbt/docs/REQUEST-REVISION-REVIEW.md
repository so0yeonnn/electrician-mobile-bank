# Bounded independent requirement-revision review

Reviewed 2026-10-29, revision `2026-10-29-policy-2`; read-only app review. Only this evidence report was written. Used verify-work skill. No git metadata exists at /workspace/electric-cbt (`git status --short`: exit128), so repository diff/history was unavailable.

Verdict: **rejected for classification-quality completion; confirmed for the bounded requirement/policy revision and preserved question data.** Whole-corpus completion is explicitly outside this confirmed scope and remains incomplete. Runtime verification is supported by producer logs, not an independently rerun browser session.

## Contract

Confirmed by direct inspection:

- docs/REQUIREMENTS.md, README.md, docs/CONTENT.md, docs/SOURCE-ANALYSIS.md, docs/VERIFICATION.md and starter metadata require only summary + exam PDFs. No current missing-selection-table dependency/request found. Legacy `selection` is accepted only for compatibility; App.tsx:65 removes old selection source rows. Existing stored/custom pack prose can remain old when a migration cannot fetch new content; no replacement or deletion of user-modified packs occurs.
- Starter policy specifies2019–2025, all-supplied-exams, prerequisite/common-core strategy, concept→formula→easy-past→applied-past→variant, reserved additional/mock, and exclude-unverified. This declares analysis scope, not a completed corpus inventory.
- Exactly DAY01–03,19 classifications,9 past questions remain. All19 currently core is consistent with this selected demo and does not prove a corpus-wide prioritization.
- src/learning.ts:4–9 filters eligibility/core and sorts past stage then difficulty, preserving additional/mock records. App.tsx:42 uses it for the daily past/generated screens; :55 uses eligibility on review. No additional/mock execution screen is implemented, and current documentation/UI says so.
- App.tsx:48 requires at least3 eligible core past questions before offering its past phase. Thus1–2 core items are deferred even if available; this is the existing3–6-question lesson contract, not proof every core item is taught.
- Source integrity check with a Node JSON comparison against tests/fixtures/sourced-v02-pack.json found19 old/new IDs and **zero differences in every question field except classification**, including answer, choices, source, verification, explanation, context, image data and check. Image base64 was compared programmatically, not printed. No source integrity regression found. This does not reverify original PDFs.
- useStore.ts:9–13 clones progress and resets sessions only for original0.1; original0.2 preserves the entire progress object. legacy.ts checks exact normalized fingerprints, not revision alone. Existing custom packs are preserved. Raw fixture JSON hash differs due to normalization/order; tests/domain.test.ts explicitly verifies parsePack(fixture) recognition.

## Blocking quality finding

Axis contract/quality; category coverage; severity medium; confidence high. New per-question classification has incorrectly reused metadata:

1. public/content/starter.json:1092,1150 (`g-divider`) asks20V with3Ω/7Ω series voltage division, but tags battery internal resistance (`전지내부저항직병렬`) and gives a battery/identical parallel-group rationale. Voltage division is missing from concepts.
2. starter.json:1023,1079 (`g-parallel`) asks unequal4Ω/12Ω parallel resistance, but labels `동일저항병렬`.
3. starter.json:2120,2200 (`p-2024-1-61`) solves two KCL node equations then resistor power; the rationale is copied from simple constant-resistance power proportionality instead of explaining this applied prerequisite bridge.

The same values occur in public/content/question-classification.csv:9,10,20. Smallest fix: correct classification concepts/rationale only, regenerate the CSV, rerun relevant content checks. Preserve all original question fields. These issues mean the19-classification count is confirmed, but reliable classification of every item cannot yet be accepted.

## Evidence inspected

Read src/content.ts, src/learning.ts, src/App.tsx (learning, review, library and imports), src/useStore.ts, src/legacy.ts, starter JSON excluding displayed image data, listed documentation, tests/learning.test.ts, tests/sourced.test.ts, tests/domain.test.ts and tests/e2e/app.spec.ts pertinent migration/order assertions.

Commands: `rg --files`, `rg -n`, `cat`, `sed -n`, `nl -ba`, `sha256sum`; Node script enumerating current/archived question fields and classifications. All successful inspection commands exit0 except the absent-git check and a missing test-results-directory inventory. No tests/build rerun by this reviewer.

Producer logs inspected:

- /tmp/cbt-evidence/request-revision-tests.log: `npm test` / `vitest run`,14 passed across4 files.
- /tmp/cbt-evidence/request-revision-build.log: `npm run build`, tsc and Vite completed; `built in5.13s`, PWA precache generated. Annotation/chunk-size warnings are nonfatal.
- /tmp/cbt-evidence/request-revision-browser.log: `npm run test:e2e`,7 passed(21.9s), including original0.2 full progress equality, two-PDF library/no-selection-text assertion, three-day offline flow, ordering and prior0.1 migration. Source tests inspect a representative migration record, not every possible user state. No flaky retries shown.
- /tmp/cbt-evidence/playwright-report/index.html exists, but no parsed fresh machine-readable report was independently inspected. Therefore browser claims are log-supported, not an independent runtime pass under the strict verify-work browser evidence rule.

Source-state binding (SHA256): starter c6b21165febcdb7a0770bb65246d0ce3747279f54fb8d95f097a847e5fdb7255; content.ts c3384877bfbb0cf9cbf9961bb93e8ee3e37a557b80e97a2e859c2762624b1ef9; learning.ts e8d9e3ea9cc5e989b5ebd054368cac67b7e26db7627a8d8157993b108cb5d1d2; App.tsx27ec502278e3a59708420451b5a904b98d238d2c3cf5afdf5d28e4a67475f5d7; useStore.ts ce358d2149eb93a637d4d5913f33d5c8d3357a35bd3027040b3ccdbdd91f4fd0; legacy.ts9dd90245dee4a78cde3690ab33084b897075d47a0740c7dec428d98315fc1658.

No corpus-wide classification/source verification, new CBT mode, remote publication, Safari/iOS/Firefox, or all failure-path migration coverage is confirmed. Review ends here; changed artifacts require a fresh bounded recheck.

## Independent recheck after classification correction — supersedes blocker verdict above

**Final bounded verdict: confirmed for requirement revision and the19-question demo classification/source-integrity scope. No remaining blocking finding within this scope.** The earlier three classification findings are resolved. This does not assert7-year whole-corpus completion or additional/mock execution screens.

Inspected all19 updated classifications against their actual prompts and retained explanations. `g-divider` now describes voltage division and same series current; `g-parallel` now describes unequal two-resistor parallel resistance; `p-2024-1-61` now explains node KCL, simultaneous equations and resistor power. The other16 classifications now also use individual problem-specific concepts and rationales. Difficulty and priority remain acknowledged learning-design estimates.

Reexecuted read-only Node comparison: `NONCLASSIFICATION_CHANGES []` for all19 questions against archived0.2. Reexecuted Python `csv.reader` cross-check:20 rows(header+19), every row exactly matches current JSON question ID/type/provenance/subject/concepts/prerequisites/difficulty/priority/stage/status/rationale. Real20 CRLF separators, zero literal escaped separators. No missing or extra rows.

Updated source-state binding: starter SHA256 `479eddedd4240132ad01ec7bc2b0f7adb58770aac48a4dde03e98ce224991136`; CSV SHA256 `cbb17393bcab224ceacbafe7684d46827944ddafc5346ba0168a5be186b9af9c`. Both edited08:20:38 UTC. App/source-policy files and REQUIREMENTS hashes remain unchanged from first review.

Fresh producer evidence after that edit, separately checked rather than reusing old success:

- request-revision-tests.log: run starts08:21:14,14 passed/4 files.
- request-revision-build.log: modified08:20:48, `built in5.14s`, PWA generated50 precache entries.
- request-revision-browser.log: final7 passed(22.8s), including old0.2 exact full progress equality and no-selection text test; no retries configured.
- Independently parsed the embedded base64 ZIP in the fresh Playwright HTML report(modified08:21:38), then `report.json`: total7, expected7, unexpected0, flaky0, skipped0, ok true; app.spec.ts has the same counts. This closes the earlier missing parsed-report evidence gap for the producer's runtime run. No independent browser execution by this reviewer was performed.

Commands on this recheck: Node original-field comparison/printed classification inventory; Python CSV exact-row comparison; `sha256sum`, `stat`, `tail`, report JSON extraction. All completed exit0. Only this report was appended. Original limitations outside this bounded contract remain; review ends here.

## Final offline CSV correction recheck

**Confirmed:** classification CSV is now precached and available offline in the exercised Chromium flow. Scope and prior source-integrity verdict remain unchanged.

Read-only inspection of vite.config.ts finds only the requested CSV inclusion in VitePWA includeAssets. tests/e2e/app.spec.ts:11 now waits for an active service-worker controller, sets the browser offline, reloads, then fetches `/content/question-classification.csv`, asserts HTTP success and20 lines. The red evidence `/tmp/cbt-evidence/revision-csv-red.log` shows this actual fetch failing before the fix (`TypeError: Failed to fetch`,1 failed); this check reaches the relevant behavior.

Fresh build log ends `built in5.44s`,51 precache entries; generated dist/sw.js timestamp08:22:46 follows config edit08:22:37. Its precache contains `content/question-classification.csv` with revision `0268f85efe40c18f84b430d296eacb27`, matching the actual CSV MD5. dist/content/question-classification.csv and public/content/question-classification.csv are byte-identical. Starter and CSV SHA256 remain respectively479eddedd4240132ad01ec7bc2b0f7adb58770aac48a4dde03e98ce224991136 and cbb17393bcab224ceacbafe7684d46827944ddafc5346ba0168a5be186b9af9c.

Fresh browser log finishes08:23:24:7 passed(23.7s), including the offline CSV assertion in the full three-day flow. Independently reparsed that fresh HTML report timestamp08:23:24: total7, expected7, unexpected0, flaky0, skipped0, ok true. Earlier08:21 browser results were not used to close this correction. Unit tests were not rerun for the configuration/e2e-only correction; earlier fresh14-unit pass remains scoped to unchanged app/content logic.

No independent browser invocation was performed by reviewer. Inspected config, added test, generated service-worker manifest entry, actual public/dist CSV bytes, red/build/browser logs and embedded report JSON; no app files changed. No remaining blocker in this bounded correction; review ends here.

Final freshness addendum: root also reran unit tests for the final state. Re-read request-revision-tests.log: start08:23:00/01 UTC,4 files passed,14 tests passed. This supersedes the preceding statement that units were not rerun. Final build, unit and parsed7-test browser results all follow the final code/test edits. Final bounded verdict remains **confirmed**, with no outstanding blocker in requirement revision,19-question classification/source preservation, migration exercised, or offline CSV availability exercised. Whole-corpus completion and separate additional/mock screens remain unimplemented and unclaimed.
