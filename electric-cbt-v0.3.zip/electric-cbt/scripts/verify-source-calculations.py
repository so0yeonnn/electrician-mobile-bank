"""Independent arithmetic for the selected supplied-source questions; no answer/data imports."""
from math import isclose
# 2025-2 Q11: dimensions/definitions: rho*l/A, sigma=1/rho. False proportionality choice3.
assert (2*5/3)/(2*2.5/3)==2
print('2025-2 Q11: length proportional, false choice3')
r20=1.69e-8*200/(2.5e-6);r60=r20*(1+.00393*(60-20))
assert isclose(r20,1.352) and isclose(r60,1.5645344) and round(r60,2)==1.56
print('2025-3 Q11:',r20,r60,'ohm -> choice3')
# Nonzero uniform J=(1,0,0) has divergence0: no accumulation != no current.
assert sum([0,0,0])==0 and any([1,0,0])
print('2025-3 Q14: nonzero uniform current density has divergence0 -> choice4')
voc=100*30/(20+30);rth=1/(1/20+1/30)
assert isclose(voc,60) and isclose(rth,12)
print('2023-1 Q63:',voc,'V,',rth,'ohm -> choice1')
assert isclose(1/(5/10),2)
print('2023-1 Q64: 2 ohm -> choice3')
assert isclose(.1*10/5,.2)
print('2023-2 Q71: 0.2 ohm -> choice4')
assert isclose(1000*.8**2,640)
print('2025-1 Q61: 640 W -> choice3')
# Solve 26Va−Vb=540 and −Va+5Vb=−120 by elimination, independently of textbook Thevenin solution.
vb=(-120*26+540)/(5*26-1);va=5*vb+120
assert isclose(va,20) and isclose(vb,-20)
assert abs((va-27)/1+va/4+(va-vb)/20)<1e-10
assert abs((vb-va)/20+vb/5+6)<1e-10
i=(va-vb)/20;power=i*i*20
assert isclose(power,80)
# Total resistor dissipation balances ideal voltage/current source supply.
loss=(27-va)**2+va**2/4+power+vb**2/5
supply=27*(27-va)-vb*6
assert isclose(loss,supply)
print('2024-1 Q61:',va,vb,'V,',i,'A,',power,'W; source balance',loss,'W -> choice4')
eta=40000*860/(5000*20000)*100
eta_exact=40000*3.6e6/(5000*4184*20000)*100
assert isclose(eta,34.4) and round(eta_exact,1)==34.4
print('2022-1 Q22:',eta,eta_exact,'% -> choice3')
print('All selected numerical/conceptual checks passed; not proof of whole-book accuracy.')
