import {describe,it,expect} from 'vitest';
import starter from '../public/content/starter.json';
import {parsePack,computeCheck,eligible} from '../src/content';
import {gradeRecallFormula,recordAttempt,dueReviews} from '../src/domain';
import {emptyProgress,parseBackup,saveStored,loadStored} from '../src/storage';
import 'fake-indexeddb/auto';
const p=parsePack(starter);
describe('학습 콘텐츠 검산과 출제 경계',()=>{
 it('세 단원의 자체 제작 독립 수치 기대값이 정답과 일치한다',()=>{
  const expected=[3,5,2.4,0.2,3,6,7,12,3,360];
  const questions=p.days.flatMap(d=>d.questions).filter(q=>q.type==='generated');
  expect(questions.map(q=>q.choices[q.answer].value)).toEqual(expected);
  questions.forEach((q,i)=>{expect(computeCheck(q.check!)).toBeCloseTo(expected[i],8);expect(eligible(q)).toBe(true);});
  expect(questions.filter(q=>q.type==='past')).toHaveLength(0);
 });
 it('모든 공식 정답은 채점 가능하고 KaTeX 텍스트와 별도로 식을 유지한다',()=>{p.days.flatMap(d=>d.formulas).forEach(f=>expect(gradeRecallFormula(f.expression,f)).toBe(true));});
 it('PDF 원문·OCR·선택지·회로도 대조 없는 기출은 차단한다',()=>{
  const q=structuredClone(p.days[0].questions[0]);q.type='past';q.source={book:'검수 테스트용 가상 교재',year:2020,round:'1회',number:1,page:1,reference:'가상 테스트 원문'};
  expect(eligible(q)).toBe(false);
  Object.assign(q.verification,{imageCompared:true,ocrCompared:true,choicesCompared:true,diagramCompared:true});expect(eligible(q)).toBe(true);
  q.verification.status='suspected';expect(eligible(q)).toBe(false);
 });
 it('단위 변환 오류와 참조 오류가 있는 콘텐츠는 가져오지 않는다',()=>{
  const bad=structuredClone(starter);bad.days[0].questions[3].check!.expected=200;expect(()=>parsePack(bad)).toThrow('수치 검산 불일치');
  const ref=structuredClone(starter);ref.days[1].formulas[0].conceptId='absent';expect(()=>parsePack(ref)).toThrow('없는 개념');
  const dup=structuredClone(starter);dup.days[1].id='day-01';expect(()=>parsePack(dup)).toThrow();
 });
});
describe('자동 복습과 저장·복원',()=>{
 it('찍어 맞힌 문제도 등록하고 오래 쉬어도 날짜 수만큼 문제를 누적하지 않는다',()=>{
  let progress=recordAttempt(emptyProgress(),{itemId:'g-ohm',conceptId:'ohm',kind:'question',correct:true,confidence:'guess'},'2026-10-29');
  expect(progress.reviews['g-ohm'].dates).toEqual(['2026-10-30','2026-11-01','2026-11-05','2026-11-12']);
  expect(dueReviews(progress,'2026-12-01')).toHaveLength(1);
  progress=recordAttempt(progress,{itemId:'g-ohm',conceptId:'ohm',kind:'question',correct:true,confidence:'sure'},'2026-11-01');
  expect(progress.reviews['g-ohm'].dates).toEqual(['2026-11-05','2026-11-12']);
 });
 it('IndexedDB에 입력과 복습을 저장하고 전체 백업으로 복원한다',async()=>{
  const snapshot={pack:p,progress:recordAttempt(emptyProgress(),{itemId:'f-current',conceptId:'ohm',kind:'formula',correct:false,confidence:'unsure'},'2026-10-29')};
  await saveStored(snapshot);expect(await loadStored()).toEqual(snapshot);
  const backup={format:'electric-cbt-backup',version:1,exportedAt:new Date().toISOString(),...snapshot};
  expect(parseBackup(JSON.parse(JSON.stringify(backup))).progress).toEqual(snapshot.progress);
  const bad=structuredClone(backup);bad.progress.attempts[0].itemId='absent';expect(()=>parseBackup(bad)).toThrow('없는 학습 기록');
 });
});
