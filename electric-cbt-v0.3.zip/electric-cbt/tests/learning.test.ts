import {it,expect} from 'vitest';
import {parsePack} from '../src/content';
import {selectDailyQuestions} from '../src/learning';
import starter from '../public/content/starter.json';
it('연도가 아닌 기초→응용 순서로 핵심 기출만 선택하고 미검수는 제외한다',()=>{
 const day=structuredClone(parsePack(starter).days[2]);
 const p=day.questions.filter(q=>q.type==='past');
 const tagged=(q:typeof p[number],priority:string,stage:string,difficulty:number)=>Object.assign(q,{classification:{subject:'회로이론 및 제어공학',concepts:['전력'],prerequisiteConceptIds:['ohm'],difficulty,priority,stage,rationale:'전기직 공통 회로 원리'}});
 tagged(p[0],'core','applied-past',4);tagged(p[1],'additional','easy-past',1);tagged(p[2],'core','easy-past',1);
 const mock=tagged(structuredClone(p[0]),'mock','easy-past',1);mock.id='mock-only';day.questions.push(mock);
 const unverified=structuredClone(p[2]);unverified.id='unverified';unverified.verification.status='unreviewed';day.questions.push(unverified);
 expect(selectDailyQuestions(day,'past').map(q=>q.id)).toEqual([p[2].id,p[0].id]);
});
it('분석 정책은 두 PDF와7개년 전체를 지정한다',()=>{
 const p=parsePack(starter) as any;
 expect(p.sources.map((s:any)=>s.type)).toEqual(['summary','exams']);
 expect(p.learningPolicy?.analysisYears).toEqual({from:2019,to:2025});
 expect(p.days.flatMap((d:any)=>d.questions).every((q:any)=>q.classification)).toBe(true);
});
it('새 정책의 누락 분류와 없는 선수 개념 및3개년 축소를 거절한다',()=>{
 const missing=structuredClone(starter) as any;delete missing.days[0].questions[0].classification;expect(()=>parsePack(missing)).toThrow('문항 분류');
 const absent=structuredClone(starter) as any;absent.days[0].questions[0].classification.prerequisiteConceptIds=['absent'];expect(()=>parsePack(absent)).toThrow('없는 선수');
 const years=structuredClone(starter) as any;years.learningPolicy.analysisYears.from=2023;expect(()=>parsePack(years)).toThrow('7개년');
});
