import {describe,it,expect} from 'vitest';
import {reviewDates,gradeFormula} from '../src/domain';
describe('회상 채점과 복습 일정',()=>{
 it('월·연도 경계를 넘어 1,3,7,14일 후 날짜를 만든다',()=>expect(reviewDates('2026-12-31')).toEqual(['2027-01-01','2027-01-03','2027-01-07','2027-01-14']));
 it('공식의 동치 표현을 허용하되 잘못된 관계와 코드 입력을 거절한다',()=>{
 const samples=[{V:12,R:4},{V:20,R:5},{V:9,R:6}];
 expect(gradeFormula('V*(1/R)','I','V/R',samples)).toBe(true);
 expect(gradeFormula('I=V/R','I','V/R',samples)).toBe(true);
 expect(gradeFormula('V*R','I','V/R',samples)).toBe(false);
 expect(gradeFormula('V/R + 1','I','V/R',samples)).toBe(false);
 expect(gradeFormula('import("x")','I','V/R',samples)).toBe(false);
 });
});

import {parsePack} from '../src/content';
import {isLegacyPack} from '../src/legacy';
import legacyPack from './fixtures/legacy-pack.json';
it('초기 번들 원본만 갱신하고 같은ID·버전의 사용자 수정 팩은 보존한다',async()=>{
 const p=parsePack(legacyPack);expect(await isLegacyPack(p)).toBe(true);
 const custom=structuredClone(p);custom.days[0].concepts[0].body[0]='사용자가 직접 수정한 개념입니다.';expect(await isLegacyPack(custom)).toBe(false);
});

import {isShippedV02Pack} from '../src/legacy';
import sourcedV02 from './fixtures/sourced-v02-pack.json';
it('0.2 배포본도 원본만 인식하고 사용자 수정 데이터는 교체하지 않는다',async()=>{const p=parsePack(sourcedV02);expect(await isShippedV02Pack(p)).toBe(true);p.days[0].title='사용자가 정한 단원';expect(await isShippedV02Pack(p)).toBe(false);});
