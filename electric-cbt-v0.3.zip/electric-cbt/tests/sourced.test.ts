import {it,expect} from 'vitest';
import starter from '../public/content/starter.json';
import {parsePack,eligible} from '../src/content';
it('제공 자료의 출처를 갖는 기출을 각 DAY에 세 문제씩 연결한다',()=>{
 const p=parsePack(starter);
 expect(p.sources?.filter(s=>s.status==='available').map(s=>s.type)).toEqual(['summary','exams']);
 for(const day of p.days){const qs=day.questions.filter(q=>q.type==='past');expect(qs).toHaveLength(3);expect(qs.every(eligible)).toBe(true);for(const q of qs){expect(q.source?.reference).toContain('PDF');expect(q.verification.independentSolution.length).toBeGreaterThan(30);}}
 expect(p.days.flatMap(d=>d.questions).filter(q=>q.type==='generated')).toHaveLength(10);
});
