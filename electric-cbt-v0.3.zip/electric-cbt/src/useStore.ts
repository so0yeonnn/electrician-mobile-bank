import {useEffect,useRef,useState} from 'react';
import {isLegacyPack,isShippedV02Pack} from './legacy';
import {parsePack,type Pack} from './content';
import {emptyProgress,loadStored,saveStored,type Progress} from './storage';
type Snapshot={pack:Pack,progress:Progress};
export function useStore(){
 const [data,setData]=useState<Snapshot>();const [error,setError]=useState('');const [saveStatus,setSaveStatus]=useState('불러오는 중');const current=useRef<Snapshot>(undefined);const queue=useRef(Promise.resolve());const pending=useRef(0);
 const persist=(snapshot:Snapshot)=>{pending.current++;setSaveStatus('저장 중…');queue.current=queue.current.catch(()=>{}).then(()=>saveStored(snapshot)).then(()=>{pending.current--;if(!pending.current)setSaveStatus('기기에 저장됨');},()=>{pending.current--;setSaveStatus('저장 실패 · 백업해 주세요');});};
 useEffect(()=>{let active=true;(async()=>{try{let snapshot=await loadStored();if(!snapshot){const response=await fetch('/content/starter.json');if(!response.ok)throw Error('초기 콘텐츠를 불러오지 못했습니다. 온라인에서 다시 열어 주세요.');snapshot={pack:parsePack(await response.json()),progress:emptyProgress()};await saveStored(snapshot);}const initialDemo=await isLegacyPack(snapshot.pack);if(initialDemo||await isShippedV02Pack(snapshot.pack)){
 try{const response=await fetch('/content/starter.json');if(response.ok){const nextPack=parsePack(await response.json());if(nextPack.revision==='2026-10-29-policy-2'){
 const progress=structuredClone(snapshot.progress);if(initialDemo)for(const session of Object.values(progress.sessions)){session.step=0;session.examDeferred=false;delete session.finishedAt;}
 snapshot={pack:nextPack,progress};await saveStored(snapshot);
 }}}catch{/* Retain existing offline data when the bundled content cannot be read. */}
 }if(active){current.current=snapshot;setData(snapshot);setSaveStatus('기기에 저장됨');}}catch(e){if(active)setError(e instanceof Error?e.message:'저장소를 열지 못했습니다.');}})();return()=>{active=false;};},[]);
 function update(fn:(s:Snapshot)=>Snapshot){if(!current.current)return;const next=fn(current.current);current.current=next;setData(next);persist(next);}
 return {data,error,saveStatus,update,flush:()=>queue.current};
}
