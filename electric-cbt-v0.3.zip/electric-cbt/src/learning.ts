import {eligible,type Day,type Question} from './content';
export const difficultyLabels=['','기초','쉬움','응용','도전'];
export const priorityLabels={core:'핵심 학습',additional:'추가 연습',mock:'실전 CBT용'};
export function selectDailyQuestions(day:Day,kind:Question['type'],short=false){
 return day.questions.filter(q=>q.type===kind&&eligible(q)&&(!q.classification||q.classification.priority==='core'))
 .sort((a,b)=>{
  const stage=(q:Question)=>q.classification?.stage==='applied-past'?1:0;
  return stage(a)-stage(b)||(a.classification?.difficulty??2)-(b.classification?.difficulty??2);
 }).slice(0,kind==='past'?6:short?2:4);
}
