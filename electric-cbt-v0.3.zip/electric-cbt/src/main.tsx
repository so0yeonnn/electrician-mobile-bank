import ReactDOM from 'react-dom/client';
import 'katex/dist/katex.min.css';
import './style.css';
import App from './App';
ReactDOM.createRoot(document.getElementById('root')!).render(<App/>);
if('serviceWorker' in navigator && import.meta.env.PROD){window.addEventListener('load',()=>{navigator.serviceWorker.register('/sw.js').catch(()=>{/* settings explains offline setup */});});}
